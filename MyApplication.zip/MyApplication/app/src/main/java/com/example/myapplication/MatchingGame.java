package com.example.myapplication;

import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.MatchingGameBinding;

import java.util.ArrayList;
import java.util.*;


public class MatchingGame extends Fragment {

    //global variables
    private @NonNull
    MatchingGameBinding binding;
    int idFirstButtonClicked = -1;
    int idSecondButtonClicked = -1;

    public class CardText {
        //cardText object creation
        String cardVal;
        int checker;

        public CardText(String strDisplay, int x) {
            cardVal = strDisplay;
            checker = x;
        }
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = MatchingGameBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //create and populate cardList array list with cardText objects
        ArrayList<CardText> cardList = new ArrayList<CardText>();
        cardList.add(new CardText("1", 1));
        cardList.add(new CardText("2", 2));
        cardList.add(new CardText("3", 3));
        cardList.add(new CardText("4", 4));
        cardList.add(new CardText("5", 5));
        cardList.add(new CardText("6", 6));
        cardList.add(new CardText("7", 7));
        cardList.add(new CardText("8", 8));
        cardList.add(new CardText("9", 9));
        cardList.add(new CardText("10", 10));
        cardList.add(new CardText("uno", 1));
        cardList.add(new CardText("dos", 2));
        cardList.add(new CardText("tres", 3));
        cardList.add(new CardText("cuatro", 4));
        cardList.add(new CardText("cinco", 5));
        cardList.add(new CardText("seis", 6));
        cardList.add(new CardText("siete", 7));
        cardList.add(new CardText("ocho", 8));
        cardList.add(new CardText("nueve", 9));
        cardList.add(new CardText("diez", 10));

        //randomize order
        Collections.shuffle(cardList, new Random());

        HashMap<String, CardText> completeList = new HashMap<String, CardText>();

        //set text on each button
        for (int i = 0; i < 20; i++) {

            //populate hash map
            completeList.put(Integer.toString(buttonIds[i]), cardList.get(i));

            ToggleButton tempButton = (ToggleButton) view.findViewById(buttonIds[i]);
            tempButton.setTextOn(cardList.get(i).cardVal);
            tempButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    //find which button was pressed
                    ToggleButton buttonClicked = (ToggleButton) view;

                    buttonClicked.setEnabled(false);

                    //first button pressed
                    if (idFirstButtonClicked == -1) {
                        idFirstButtonClicked = buttonClicked.getId();//index of button that was pressed
                    }
                    //second button pressed
                    else {
                        idSecondButtonClicked = buttonClicked.getId();//index of button that was pressed
                        View x = (View) buttonClicked.getParent();
                        ToggleButton firstButton = (ToggleButton) x.findViewById(idFirstButtonClicked);

                        //disable all buttons once two are selected
                        for(int z = 0; z < 20; z++) {
                            ToggleButton buttonDisable = (ToggleButton) x.findViewById(buttonIds[z]);
                            buttonDisable.setEnabled(false);
                        }
                        //extract the cardText object for checking
                        CardText first = (CardText) completeList.get(Integer.toString(idFirstButtonClicked));
                        CardText second = (CardText) completeList.get(Integer.toString(idSecondButtonClicked));

                        //add delay to see the results of the cards
                        Handler handler = new Handler(Looper.myLooper());
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                //if right the cards go invisible
                                if (first.checker == second.checker) {
                                    //make cards disappear
                                    buttonClicked.setVisibility(View.GONE);
                                    firstButton.setVisibility(View.GONE);
                                }
                                //if wrong the cards flip
                                else {
                                    buttonClicked.setChecked(false);
                                    firstButton.setChecked(false);
                                }
                                //reset
                                idFirstButtonClicked = -1;
                                //enable all visible buttons
                                for(int zz = 0; zz < 20; zz++) {
                                    ToggleButton buttonEnable = (ToggleButton) x.findViewById(buttonIds[zz]);
                                    if (buttonEnable.getVisibility() == View.GONE) {
                                    }
                                    else {

                                        buttonEnable.setEnabled(true);
                                    }
                                }
                            }
                        }, 2150);

                    }
                }
            });
        }
        //navigate to main menu
        binding.buttonBackMm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(MatchingGame.this)
                        .navigate(R.id.action_matchingGame_to_MainMenu);
            }
        });
    }
    //int array to access to button id's in int form
    Integer[] buttonIds = {
            R.id.toggleButton0,
            R.id.toggleButton01,
            R.id.toggleButton02,
            R.id.toggleButton03,
            R.id.toggleButton04,
            R.id.toggleButton05,
            R.id.toggleButton06,
            R.id.toggleButton07,
            R.id.toggleButton08,
            R.id.toggleButton09,
            R.id.toggleButton010,
            R.id.toggleButton011,
            R.id.toggleButton012,
            R.id.toggleButton013,
            R.id.toggleButton014,
            R.id.toggleButton015,
            R.id.toggleButton016,
            R.id.toggleButton017,
            R.id.toggleButton018,
            R.id.toggleButton019
    };
}
