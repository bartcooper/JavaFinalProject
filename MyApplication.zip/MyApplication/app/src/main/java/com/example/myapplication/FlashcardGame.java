package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.FlashcardGameBinding;

public class FlashcardGame extends Fragment {

    //global variables
    private @NonNull
    FlashcardGameBinding binding;
    int index = 0;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FlashcardGameBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        resetButton(fcArr[index]);

        //when next button is clicked the flashcard will change to the next card
        binding.buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                index++;
                //reset the flashcards once the final flashcard is done
                int len = fcArr.length;
                if (index == len) {
                    index = 0;
                }
                resetButton(fcArr[index]);
            }
        });

        //navigate back to the main menu
        binding.buttonBackMm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(FlashcardGame.this)
                        .navigate(R.id.action_flashcardGame_to_MainMenu);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public class flashcard {
        //create flashcard object
        String front;
        String back;

        public flashcard(String a, String b) {
            this.front = a;
            this.back = b;
        }
    }

    //method to reset state of button when next button is clicked
    public void resetButton (flashcard fc) {
        binding.toggleButton.setTextOff(fc.front);
        binding.toggleButton.setTextOn(fc.back);
        binding.toggleButton.setChecked(false);
    }
    //array of flashcards
    //elements go on either side of the card
    flashcard[] fcArr = {
            new flashcard("1","uno"),
            new flashcard("2","dos"),
            new flashcard("3","tres"),
            new flashcard("4","cuatro"),
            new flashcard("5","cinco"),
            new flashcard("6","seis"),
            new flashcard("7","siete"),
            new flashcard("8","ocho"),
            new flashcard("9","nueve"),
            new flashcard("10","diez")
    };
}
